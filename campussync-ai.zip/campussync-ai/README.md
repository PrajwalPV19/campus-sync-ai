CampusSync AI - README.md
Project Overview
CampusSync AI is an AI-powered orchestration platform designed to resolve fragmentation in India's higher education system. It centralizes student academic information, grievance management, credit transfers, and placement workflows into one seamless web application. This project includes a Node.js backend with Express and MongoDB and a Bootstrap-based frontend.

Prerequisites
Node.js (v18 or higher recommended) & npm installed

MongoDB running locally or accessible remotely (e.g., MongoDB Atlas)

Git (optional)

VSCode or any code editor

Setup Instructions
1. Clone the repository
bash
git clone <repository_url>
cd campussync-ai/server
2. Install dependencies
bash
npm install
This installs all backend packages including Express, Mongoose, bcrypt, dotenv, etc.

3. Configure Environment Variables
Create a .env file in the server folder:

text
MONGODB_URI=mongodb://localhost:27017/campussync
PORT=5000
JWT_SECRET=your_super_secret_jwt_key_here
NODE_ENV=development
Replace MONGODB_URI with your MongoDB connection string if different.

4. Start the Server (Development)
Start the backend server with nodemon for auto-reloading:

bash
npm run dev
Alternatively, start normally:

bash
npm start
The API backend runs on http://localhost:5000 by default.

5. Open Frontend Views
Open the views/ folder HTML files in your browser or use a simple HTTP server like:

bash
npx serve views
This serves static pages to interact with the backend.

Project Structure
server/ - Backend code and APIs

models/ - Mongoose schemas

routes/ - Express route handlers

controllers/ - Route logic controllers

utils/ - Utilities (db connection, helpers)

app.js - Express server entrypoint

views/ - Static HTML frontend pages

public/ - CSS, JS, images

.env - Environment variables config

README.md - This file

Usage
Use /api/auth for authentication (sign up, login)

/api/students to manage student data

/api/grievances for grievance filing and tracking

/api/credits for ABC credit management

/api/placements for placement data and updates

Example: File a grievance via POST to /api/grievances with JSON payload:

json
{
  "student": "<student_id>",
  "title": "Issue title",
  "description": "Issue details",
  "category": "Academic"
}
Development Tips
Use Postman or similar tools to test API endpoints

Add JWT authentication on frontend for secure access

Extend React or other frontend frameworks to replace static views

Use MongoDB Atlas for scalable remote DB hosting

Implement real AI models for grievance auto-categorization & credit validation

Troubleshooting
Ensure MongoDB connection string is correct and MongoDB service is running

Run npm install to update packages if errors occur

Restart server after changing .env variables

Check server console logs for errors during runtime