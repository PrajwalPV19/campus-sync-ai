// public/js/main.js

document.addEventListener('DOMContentLoaded', () => {

    // Grievance form submission handler
    const grievanceForm = document.getElementById('grievanceForm');
    if (grievanceForm) {
        grievanceForm.addEventListener('submit', async(e) => {
            e.preventDefault();

            const title = grievanceForm.title.value.trim();
            const description = grievanceForm.description.value.trim();
            const category = grievanceForm.category.value;

            if (!title || !description || !category) {
                alert('Please fill all grievance fields.');
                return;
            }

            const grievanceData = { title, description, category };

            // TODO: Replace URL with your API endpoint
            const apiUrl = '/api/grievances';

            try {
                const response = await fetch(apiUrl, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(grievanceData),
                });

                if (response.ok) {
                    alert('Grievance filed successfully!');
                    // Reset form
                    grievanceForm.reset();
                    // Close modal (Bootstrap 5)
                    const modal = bootstrap.Modal.getInstance(document.getElementById('fileGrievanceModal'));
                    modal.hide();
                } else {
                    const error = await response.json();
                    alert(`Failed to file grievance: ${error.message || response.statusText}`);
                }
            } catch (err) {
                alert(`Error submitting grievance: ${err.message}`);
            }
        });
    }

    // Example: Initialize Bootstrap tooltips (if you add any)
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(tooltipTriggerEl => {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Add more frontend JS as needed

});