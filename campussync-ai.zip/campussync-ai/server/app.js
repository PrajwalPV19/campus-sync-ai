// server/app.js

const express = require('express');
const path = require('path');
const dotenv = require('dotenv');
const cors = require('cors');
const connectDB = require('./utils/db');

// Load environment variables from .env file
dotenv.config();

// Import route handlers
const authRoutes = require('./routes/auth');
const studentRoutes = require('./routes/students');
const grievanceRoutes = require('./routes/grievances');
const creditRoutes = require('./routes/credits');
const placementRoutes = require('./routes/placements');

const app = express();

// Middleware
app.use(cors());
app.use(express.json()); // Parse JSON bodies

// Connect to MongoDB
connectDB(process.env.MONGODB_URI);

// Serve static frontend assets (public) and views
app.use(express.static(path.join(__dirname, '..', 'public')));
app.use('/views', express.static(path.join(__dirname, '..', 'views')));

// Health check / serve frontend index
app.get('/', (req, res) => {
    // Send the frontend index so links like /css/styles.css resolve correctly
    res.sendFile(path.join(__dirname, '..', 'views', 'index.html'));
});

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/students', studentRoutes);
app.use('/api/grievances', grievanceRoutes);
app.use('/api/credits', creditRoutes);
app.use('/api/placements', placementRoutes);

// Global error handler middleware (optional enhancement)
app.use((err, req, res, next) => {
    console.error(err.stack);
    const status = res.statusCode === 200 ? 500 : res.statusCode;
    res.status(status).json({
        message: err.message || 'Server Error',
        stack: process.env.NODE_ENV === 'production' ? null : err.stack,
    });
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});