const mongoose = require('mongoose');

const notificationSchema = new mongoose.Schema({
    student: { type: mongoose.Schema.Types.ObjectId, ref: 'Student', required: true },
    type: { type: String, enum: ['Upcoming', 'Opportunity', 'Grievance'], required: true },
    title: { type: String, required: true },
    description: { type: String },
    actionUrl: { type: String },
    actionText: { type: String },
    isRead: { type: Boolean, default: false },
    timestamp: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Notification', notificationSchema);