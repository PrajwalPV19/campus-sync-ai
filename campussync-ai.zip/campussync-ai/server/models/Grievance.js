const mongoose = require('mongoose');

const grievanceSchema = new mongoose.Schema({
    student: { type: mongoose.Schema.Types.ObjectId, ref: 'Student', required: true },
    title: { type: String, required: true, maxlength: 200 },
    description: { type: String },
    category: { type: String, enum: ['Academic', 'Administrative', 'Facilities', 'Placement', 'Other'], required: true },
    status: { type: String, enum: ['Open', 'In-Review', 'Resolved'], default: 'Open' },
    filedDate: { type: Date, default: Date.now },
    slaDeadline: { type: Date },
    daysRemaining: { type: Number },
    assignedTo: { type: String },
    estimatedResolution: { type: Number },
    progressPercentage: { type: Number, min: 0, max: 100, default: 0 },
    priority: { type: String, enum: ['High', 'Medium', 'Low'], default: 'Medium' }
});

module.exports = mongoose.model('Grievance', grievanceSchema);