const mongoose = require('mongoose');

const placementSchema = new mongoose.Schema({
    student: { type: mongoose.Schema.Types.ObjectId, ref: 'Student', required: true },
    applied: { type: Boolean, default: false },
    companiesApplied: [{ type: String }],
    profileCompleteness: { type: Number, min: 0, max: 100, default: 0 },
    nextDriveDate: { type: Date },
    companiesRecruiting: [{ type: String }]
});

module.exports = mongoose.model('Placement', placementSchema);