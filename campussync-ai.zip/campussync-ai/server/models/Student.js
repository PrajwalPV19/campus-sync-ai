const mongoose = require('mongoose');
const bcrypt = require('bcrypt');

// Embedded Credit schema
const creditSchema = new mongoose.Schema({
    subject: { type: String, required: true },
    credits: { type: Number, required: true },
    grade: { type: String, enum: ['A', 'A-', 'B+', 'B', 'C', 'F'], required: true },
    transferable: { type: Boolean, default: false }
});

// Embedded Placement schema
const placementSchema = new mongoose.Schema({
    applied: { type: Boolean, default: false },
    companiesApplied: [{ type: String }],
    completeness: { type: Number, min: 0, max: 100, default: 0 },
    nextDriveDate: { type: Date },
    companiesRecruiting: [{ type: String }]
});

// Embedded Notification schema
const notificationSchema = new mongoose.Schema({
    type: { type: String, enum: ['upcoming', 'opportunity', 'grievance'], required: true },
    title: { type: String, required: true },
    description: { type: String },
    actionUrl: { type: String },
    actionText: { type: String },
    isRead: { type: Boolean, default: false },
    timestamp: { type: Date, default: Date.now }
}, { _id: false });

// Main Student schema
const studentSchema = new mongoose.Schema({
    name: { type: String, required: true, maxlength: 120 },
    email: { type: String, required: true, unique: true, lowercase: true },
    password: { type: String, required: true, select: false },
    abcId: { type: String, required: true, unique: true },
    enrollmentYear: { type: Number, required: true },
    currentSemester: { type: Number, default: 1 },
    institution: { type: mongoose.Schema.Types.ObjectId, ref: 'Institution' },
    program: { type: String, required: true },
    abcCredits: [creditSchema],
    totalCredits: { type: Number, default: 0 },
    requiredCredits: { type: Number, default: 60 },
    creditsExpiryDate: { type: Date },
    placementStatus: placementSchema,
    notifications: [notificationSchema],
    isActive: { type: Boolean, default: true },
    lastLogin: { type: Date },
    createdAt: { type: Date, default: Date.now },
    updatedAt: { type: Date, default: Date.now }
});

// Password hash middleware
studentSchema.pre('save', async function(next) {
    if (!this.isModified('password')) return next();
    this.password = await bcrypt.hash(this.password, 10);
    next();
});

// Password comparison method
studentSchema.methods.comparePassword = function(candidatePassword) {
    return bcrypt.compare(candidatePassword, this.password);
};

module.exports = mongoose.model('Student', studentSchema);