const express = require('express');
const router = express.Router();
const Student = require('../models/Student');

// Get placement status for student
router.get('/student/:studentId', async(req, res) => {
    try {
        const student = await Student.findById(req.params.studentId, 'placementStatus');
        if (!student) return res.status(404).json({ error: 'Student not found' });
        res.json(student.placementStatus);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Server error' });
    }
});

// Update placement info
router.patch('/student/:studentId', async(req, res) => {
    try {
        const updates = req.body;
        const student = await Student.findById(req.params.studentId);
        if (!student) return res.status(404).json({ error: 'Student not found' });

        student.placementStatus = {...student.placementStatus.toObject(), ...updates };
        await student.save();

        res.json(student.placementStatus);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Server error' });
    }
});

module.exports = router;