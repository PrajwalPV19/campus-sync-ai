const express = require('express');
const router = express.Router();
const Student = require('../models/Student');

// Get student details by ID
router.get('/:id', async(req, res) => {
    try {
        const student = await Student.findById(req.params.id).populate('institution');
        if (!student) return res.status(404).json({ error: 'Student not found' });
        res.json(student);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Server error' });
    }
});

// Update student profile (partial updates)
router.patch('/:id', async(req, res) => {
    try {
        const updates = req.body;
        const student = await Student.findByIdAndUpdate(req.params.id, updates, { new: true });
        if (!student) return res.status(404).json({ error: 'Student not found' });
        res.json(student);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Server error' });
    }
});

module.exports = router;