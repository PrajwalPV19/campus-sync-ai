const express = require('express');
const router = express.Router();
const Student = require('../models/Student');

// Get ABC credits for a student
router.get('/student/:studentId', async(req, res) => {
    try {
        const student = await Student.findById(req.params.studentId, 'abcCredits totalCredits requiredCredits creditsExpiryDate');
        if (!student) return res.status(404).json({ error: 'Student not found' });
        res.json(student);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Server error' });
    }
});

// Add a new credit record to a student
router.post('/student/:studentId', async(req, res) => {
    try {
        const credit = req.body;
        const student = await Student.findById(req.params.studentId);
        if (!student) return res.status(404).json({ error: 'Student not found' });

        student.abcCredits.push(credit);
        student.totalCredits += credit.credits;
        await student.save();

        res.json(student);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Server error' });
    }
});

module.exports = router;