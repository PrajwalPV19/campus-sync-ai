const express = require('express');
const router = express.Router();
const Grievance = require('../models/Grievance');

// Get grievances for a student
router.get('/student/:studentId', async(req, res) => {
    try {
        const grievances = await Grievance.find({ student: req.params.studentId });
        res.json(grievances);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Server error' });
    }
});

// File a new grievance
router.post('/', async(req, res) => {
    try {
        const grievance = new Grievance(req.body);
        await grievance.save();
        res.json(grievance);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Server error' });
    }
});

// Update grievance status or details
router.patch('/:id', async(req, res) => {
    try {
        const updates = req.body;
        const grievance = await Grievance.findByIdAndUpdate(req.params.id, updates, { new: true });
        if (!grievance) return res.status(404).json({ error: 'Grievance not found' });
        res.json(grievance);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Server error' });
    }
});

module.exports = router;