const Student = require('../models/Student');

exports.getPlacementStatus = async(req, res) => {
    try {
        const student = await Student.findById(req.params.studentId, 'placementStatus');
        if (!student) return res.status(404).json({ error: 'Student not found' });
        res.json(student.placementStatus);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
};

exports.updatePlacement = async(req, res) => {
    try {
        const updates = req.body;
        const student = await Student.findById(req.params.studentId);
        if (!student) return res.status(404).json({ error: 'Student not found' });

        student.placementStatus = {...student.placementStatus.toObject(), ...updates };
        await student.save();

        res.json(student.placementStatus);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
};