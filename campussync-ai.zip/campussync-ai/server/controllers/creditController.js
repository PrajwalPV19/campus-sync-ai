const Student = require('../models/Student');

exports.getCredits = async(req, res) => {
    try {
        const student = await Student.findById(req.params.studentId, 'abcCredits totalCredits requiredCredits creditsExpiryDate');
        if (!student) return res.status(404).json({ error: 'Student not found' });
        res.json(student);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
};

exports.addCredit = async(req, res) => {
    try {
        const credit = req.body;
        const student = await Student.findById(req.params.studentId);
        if (!student) return res.status(404).json({ error: 'Student not found' });

        student.abcCredits.push(credit);
        student.totalCredits += credit.credits;
        await student.save();

        res.json(student);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
};