const Student = require('../models/Student');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const JWT_SECRET = process.env.JWT_SECRET || 'changeme';

exports.signup = async(req, res) => {
    try {
        const { name, email, password, abcId } = req.body;
        if (!name || !email || !password || !abcId) {
            return res.status(400).json({ error: 'Missing required fields' });
        }
        const existingUser = await Student.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ error: 'Email already registered' });
        }
        const hashedPassword = await bcrypt.hash(password, 10);
        const newStudent = new Student({ name, email, password: hashedPassword, abcId, enrollmentYear: new Date().getFullYear(), program: 'Undeclared' });
        await newStudent.save();

        const token = jwt.sign({ id: newStudent._id }, JWT_SECRET, { expiresIn: '7d' });

        res.json({ token, student: { id: newStudent._id, name: newStudent.name, email: newStudent.email } });
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
};

exports.login = async(req, res) => {
    try {
        const { email, password } = req.body;
        if (!email || !password) return res.status(400).json({ error: 'Missing email or password' });

        const student = await Student.findOne({ email }).select('+password');
        if (!student) return res.status(400).json({ error: 'Invalid credentials' });

        const isMatch = await bcrypt.compare(password, student.password);
        if (!isMatch) return res.status(400).json({ error: 'Invalid credentials' });

        const token = jwt.sign({ id: student._id }, JWT_SECRET, { expiresIn: '7d' });

        res.json({ token, student: { id: student._id, name: student.name, email: student.email } });
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
};