const Grievance = require('../models/Grievance');

exports.getGrievancesByStudent = async(req, res) => {
    try {
        const grievances = await Grievance.find({ student: req.params.studentId });
        res.json(grievances);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
};

exports.fileGrievance = async(req, res) => {
    try {
        const grievance = new Grievance(req.body);
        await grievance.save();
        res.json(grievance);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
};

exports.updateGrievance = async(req, res) => {
    try {
        const updates = req.body;
        const grievance = await Grievance.findByIdAndUpdate(req.params.id, updates, { new: true });
        if (!grievance) return res.status(404).json({ error: 'Grievance not found' });
        res.json(grievance);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
};