const Student = require('../models/Student');

exports.getStudentById = async(req, res) => {
    try {
        const student = await Student.findById(req.params.id).populate('institution');
        if (!student) return res.status(404).json({ error: 'Student not found' });
        res.json(student);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
};

exports.updateStudent = async(req, res) => {
    try {
        const updates = req.body;
        const student = await Student.findByIdAndUpdate(req.params.id, updates, { new: true });
        if (!student) return res.status(404).json({ error: 'Student not found' });
        res.json(student);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
};